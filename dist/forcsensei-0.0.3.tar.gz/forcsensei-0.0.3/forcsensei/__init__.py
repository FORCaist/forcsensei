# FORCsensei module 
# give command OPENBLAS_NUM_THREADS=1 in terminal if using multithreading
# compile using: python3 setup.py sdist bdist_wheel

import os
import numpy as np
import codecs as cd
import scipy as sp
from IPython.display import YouTubeVideo
import ipywidgets as widgets
import matplotlib.pyplot as plt
#import matplotlib.style
import matplotlib as mpl
#from google.colab import files
mpl.rcParams['pdf.fonttype'] = 42
from matplotlib import rc
rc('text', usetex=True)
#from PyQt5 import QtGui, QtWidgets
#from termcolor import cprint

###
#def openfile_dialog():
#    from PyQt5 import QtGui, QtWidgets
#    app = QtWidgets.QApplication([dir])
#    fname = QtWidgets.QFileDialog.getOpenFileName(None, "Select a file...", '.', filter="All files (*)")[0]
    
#    return str(fname)

#NEW PLOTTING ROUTINES
def forc_plotting(fn,pl0,data):

    #make a fixed copy of the options
    pl = {
        "Hc1": pl0["Hc1"].value,
        "Hc2": pl0["Hc2"].value,
        "Hb1": pl0["Hb1"].value,
        "Hb2": pl0["Hb2"].value,
        "colorbar": pl0["colorbar"].value,
        "contour": pl0["contour"].value,
        "color": pl0["color"].value,
        "scale": pl0["scale"].value,
        "download": pl0["download"].value
    }

    #unpack data
    rho = data['rho']
    H = data['H']
    Hr = data['Hr']
    Hc = 0.5*(H-Hr)
    Hb = 0.5*(H+Hr)
    dH = np.mean(np.diff(H[data['Fk']==np.max(data['Fk'])])) #mean field spacing

    #create grid for interpolation
    Nx = np.ceil((pl['Hc2']- pl['Hc1'])/dH)+1 #number of points along x
    Ny = np.ceil((pl['Hb2']- pl['Hb1'])/dH)+1 #number of points along y
    xi = np.linspace(pl['Hc1'],pl['Hc2'],int(Nx))
    yi = np.linspace(pl['Hb1'],pl['Hb2'],int(Ny))
    
    #perform interpolation
    triang = tri.Triangulation(Hc, Hb)
    interpolator = tri.LinearTriInterpolator(triang, rho)
    Xi, Yi = np.meshgrid(xi, yi)
    Zi = interpolator(Xi, Yi)

    #define colormaps
    if pl['color']=='seismic':
        cmap = mpl.cm.seismic
    elif pl['color']=='spectral':
        cmap = mpl.cm.Spectral
    elif pl['color']=='PuOr':
        cmap = mpl.cm.PuOr
    elif pl['color']=='RdBu_r':
        cmap = mpl.cm.RdBu_r        
    
    #create FORC plot
    fig = plt.figure(figsize=(6,6))
    ax = fig.add_subplot(1,1,1)

    if pp['unit']=='SI':        
        CS = ax.contourf(Xi*1000, Yi*1000, Zi, 101, cmap = cmap, norm=MidpointNormalize(midpoint=0.)) #plot SI version [mT]
        #CS = ax.contourf(Xi*1000, Yi*1000, Zi, 101, cmap = pl['color'], vmin=np.min(Zi), vmax=np.max(Zi)) #plot SI version [mT]
        if pl['contour']:
            CS2 = ax.contour(CS, levels=CS.levels[::10], colors='k')
        ax.set_xlabel(r'$\mu_0 H_c~[mT]$',fontsize=14) #label Hc axis
        ax.set_ylabel(r'$\mu_0 H_u~[mT]$',fontsize=14) #label Hu axis
    else:
        CS = ax.contourf(Xi, Yi, Zi, 101, vmin=np.min(Zi), vmax=np.max(Zi)) #plot Cgs version [Oe]
        ax.set_xlabel(r'$H_c~[Oe]$',fontsize=14) #label Hc axis
        ax.set_ylabel(r'$H_u~[Oe]$',fontsize=14) #label Hu axis
    
    ax.tick_params(labelsize=14)
    ax.set_aspect('equal') #set 1:1 aspect ratio
    ax.minorticks_on() #add minor ticks
    
    if pl['colorbar']:    
        cbar = fig.colorbar(CS,fraction=0.04, pad=0.08)
        cbar.ax.tick_params(labelsize=14)
    
        if (pp['mass']>0) & (pp['unit']=='SI'): #label colorbar with appropriate units (depends on mass normalization)
            cbar.ax.set_title(r'$\frac{Am^2}{T^2 kg}$',fontsize=20)
        elif (pp['mass']<=0) & (pp['unit']=='SI'):
            cbar.ax.set_title(r'$\frac{Am^2}{T^2}$',fontsize=20)
        elif (pp['mass']>0) & (pp['unit']=='Cgs'):
            cbar.ax.set_title(r'$\frac{emu}{Oe^2 g}$',fontsize=20)
        elif (pp['mass']<=0) & (pp['unit']=='Cgs'):
            cbar.ax.set_title(r'$\frac{emu}{Oe^2}$',fontsize=20)    
    
    if pl['download']:
        idx = fn.rfind('.')
        if idx<0:
            outputfile = fn+'_FORC.pdf'
        else:
            outputfile = fn[0:idx]+'_FORC.pdf'
        
        plt.savefig(outputfile, dpi=150)
    
    plt.show()

    return pl

def plotting_options(fn,pp):

    #Get measurement limits from file (+adjust units if required)
    Hc1, Hc2, Hb1, Hb2 = fs.measurement_limts(fn,pp)

    #build widgets
    
    ## Hc limits
    if pp['unit']=='SI':
        Hc1_widge = widgets.FloatText(value=Hc1, disabled=False, description = "[T]")
        Hc2_widge = widgets.FloatText(value=Hc2, disabled=False, description = "[T]")
    else:
        Hc1_widge = widgets.FloatText(value=Hc1, disabled=False, description = "[Oe]")
        Hc2_widge = widgets.FloatText(value=Hc2, disabled=False, description = "[Oe]")

    ## Hb limits
    if pp['unit']=='SI':
        Hb1_widge = widgets.FloatText(value=Hb1, disabled=False, description = "[T]")
        Hb2_widge = widgets.FloatText(value=Hb2, disabled=False, description = "[T]")
    else:
        Hb1_widge = widgets.FloatText(value=Hb1, disabled=False, description = "[Oe]")
        Hb2_widge = widgets.FloatText(value=Hb2, disabled=False, description = "[Oe]")


    ## Colorbar
    #colorbar_text = widgets.HTML(value = "<b>Scalebar -</b> Check the box below to include a scalebar")
    colorbar_widge = widgets.Checkbox(value=False, description = 'Check me')
    
    ## Colorbar
    #contour_text = widgets.HTML(value = "<b>Contours -</b> Check the box below include contour lines")
    contour_widge = widgets.Checkbox(value=False, description = 'Check me')

    ## color map 
    #color_text = widgets.HTML(value = "<b>Color -</b> Select colormap")

    color_widge = widgets.Select(
        options=['seismic', 'spectral','PuOr','RdBu_r'],
        value='RdBu_r',
        rows=1,
        disabled=False
    )
    
    
    ## color scale
    #scale_text = widgets.HTML(value = "<b>Color scaling -</b> Select color scale type:")

    scale_widge = widgets.RadioButtons(
        options=['Linear', 'Nonlinear'],
        value='Linear',
        disabled=False
    )
    
    download_widge = widgets.Checkbox(value=False, description = 'Check me')
    
    #construct plotting accordion
    header=widgets.HTML(value = "<h2>Plotting</h2>")
    display(header)
    
    explain0=widgets.HTML(value = "In this section you can set plotting options for your final FORC distribution.")
    explain1=widgets.HTML(value = "Click on each topic to make your plotting options")
    display(explain0)
    display(explain1)

    #Construct accordion
    pl_accord = widgets.Accordion(children=[Hc1_widge,
                                        Hc2_widge,
                                        Hb1_widge,
                                        Hc2_widge,
                                        colorbar_widge,
                                        contour_widge,
                                        color_widge,
                                        scale_widge,
                                        download_widge])
    if pp['unit']=='SI':
        pl_accord.set_title(0, 'Minimum Bc: smallest field value on the horizontal axis')
        pl_accord.set_title(1, 'Maximum Bc: largest field value on the horizontal axis')
        pl_accord.set_title(2, 'Minimum Bu: smallest field value on the vertical axis')
        pl_accord.set_title(3, 'Maximum Bu: largest field value on the vertical axis')
    else:
        pl_accord.set_title(0, 'Minimum Hc: smallest field value on the horizontal axis')
        pl_accord.set_title(1, 'Maximum Hc: largest field value on the horizontal axis')
        pl_accord.set_title(2, 'Minimum Hu: smallest field value on the vertical axis')
        pl_accord.set_title(3, 'Maximum Hu: largest field value on the vertical axis"')
        
    pl_accord.set_title(4, 'Include scale bar')
    pl_accord.set_title(5, 'Include contours')
    pl_accord.set_title(6, 'Select colormap')
    pl_accord.set_title(7, 'Color scaling options')
    pl_accord.set_title(8, 'Download plot')
    display(pl_accord)    
       
    ## PACK RESULTS
    pl0 = {
            "Hc1": Hc1_widge,
            "Hc2": Hc2_widge,
            "Hb1": Hb1_widge,
            "Hb2": Hb2_widge,
            "colorbar": colorbar_widge,
            "contour": contour_widge,
            "color": color_widge,
            "scale": scale_widge,
            "download": download_widge
    }
    
    return pl0


### NEW MODEL TO CALCULATE RHO
def model(data):
    
    #unpack variables
    H = data['H']
    Hr = data['Hr']
    M = data['M']
    Fk = data ['Fk']
    Fj = data ['Fj']
    SF0 = float(data['sf'].value)
    
    rho = np.zeros(Fk.size)
    Fn = np.zeros(Fk.size)
    hat = np.zeros(Fk.size)
    
    for i in range(Fk.size):
        deltaFk = Fk-Fk[i]
        idx = (np.abs(deltaFk)<=SF0*1.1) & (np.abs(Fj-Fj[i]-deltaFk)<=SF0*1.1)
        N = np.sum(idx)
        HX = H[idx]-H[i]
        HrX = Hr[idx]-Hr[i]
        
        Fn[i] = np.sum(idx)
        Y = M[idx]
        
        X = np.column_stack((np.ones(N),HX,HX**2,HrX,HrX**2,HX*HrX))
        coeff = np.linalg.lstsq(X, Y,rcond=None)
        rho[i] = -0.5*coeff[0][5]
            
    
    #pack up result
    data['rho'] = rho        
    
    return data


### NEW PROCESSING CODES INCLUDING WIDGETS
def model_options(fn,pp,data):

    sf_widge = widgets.BoundedIntText(
        value=3,
        min=2,
        max=7,
        step=1,
        description='SF:',
        disabled=False
    )
    
    #construct plotting accordion
    header=widgets.HTML(value = "<h2>Modelling</h2>")
    display(header)
    
    explain0=widgets.HTML(value = "In this section you can set the model options used to estimate the FORC function.")
    explain1=widgets.HTML(value = "This is currently the Pike et al. [1999] algorithm, which requires a user-defined smoothing factor (sf)")
    display(explain0)
    display(explain1)
                          
    #Construct accordion
    pp_accord = widgets.Accordion(children=[sf_widge])
    pp_accord.set_title(0, 'Select Pike Smoothing Factor [2-7]:')

    display(pp_accord)    
       
    ## PACK RESULTS
    data['sf'] = sf_widge
    
    return data


### NEW PREPROCESSING CODE INCLUDING WIDGETS
def preprocessing_options(fn):

    #define sequence of widgets
    sample, units, mass = sample_details(fn)

    sample_widge = widgets.Text(value=sample)

    if mass == "N/A":
        mass_widge = widgets.FloatText(value=-1, description = 'grams')
    else:
        mass_widge = widgets.FloatText(value=mass, description = 'grams')

    unit_widge = widgets.RadioButtons(options=['SI', 'Cgs'],value="SI")
    drift_widge = widgets.Checkbox(value=False, description=' Check me')
    slope_widge = widgets.Checkbox(value=False, description=' Check me')
    fpa_widge = widgets.Checkbox(value=False, description=' Check me')
    lpa_widge = widgets.Checkbox(value=False, description=' Check me')
    outlier_widge = widgets.Checkbox(value=False, description=' Check me')
    lbs_widge = widgets.Checkbox(value=False, description=' Check me')

    plot_widge = widgets.Select(
        options=['No Plots', 'Plot results', 'Plot results and download'],
        value='Plot results',
        rows=3,
        disabled=False
        )
    
    
    header=widgets.HTML(value = "<h2>Sample preprocessing</h2>")
    display(header)
    
    explain0=widgets.HTML(value = "In this section you can set the data preprocessing options.")
    explain1=widgets.HTML(value = "Click on each topic to make your preprocessing options")
    display(explain0)
    display(explain1)

    #Construct accordion
    pp_accord = widgets.Accordion(children=[sample_widge,
                                        mass_widge,
                                        unit_widge,
                                        drift_widge,
                                        slope_widge,
                                        fpa_widge,
                                        lpa_widge,
                                        outlier_widge,
                                        lbs_widge,
                                        plot_widge])

    pp_accord.set_title(0, 'Sample name')
    pp_accord.set_title(1, 'Sample mass (use -1 to disable mass correction)')
    pp_accord.set_title(2, 'Select calculation units')
    pp_accord.set_title(3, 'Perform measurement drift correction')
    pp_accord.set_title(4, 'High-field slope correction')
    pp_accord.set_title(5, 'Remove first point artifact')
    pp_accord.set_title(6, 'Remove last point artifact')
    pp_accord.set_title(7, 'Remove outliers')
    pp_accord.set_title(8, 'Perform lower branch subtraction')
    pp_accord.set_title(9, 'Plotting options for the preprocessed data')

    display(pp_accord)

    #pack options into a dictionary
    pp0 = {
        "name": sample_widge,
        "mass": mass_widge,
        "unit": unit_widge,
        "drift": drift_widge,
        "slope": slope_widge,
        "fpa": fpa_widge,
        "lpa": lpa_widge,
        "outlier": outlier_widge,
        "lbs": lbs_widge,
        "plot": plot_widge,
        }
    
    return pp0

def preprocessing_options_old(fn):

    #Get measurement information from file
    sample, units, mass = sample_details(fn)
    
    ## horizontal line
    hline = widgets.HTML(
        value = "<hr>",
    )

    ## SAMPLE NAME
    sample_text = widgets.HTML(
        value = "<b>Sample name -</b> input sample name",
    )

    sample_widge = widgets.Text(value=sample, disabled=False)

    display(sample_text,sample_widge,hline)

    ## SAMPLE MASS
    mass_text = widgets.HTML(
        value = "<b>Sample mass -</b> input sample mass in grams (enter -1 to disable mass normalization)",
    )

    if mass == "N\A":
        mass_widge = widgets.FloatText(value=-1, disabled=False)
    else:
        mass_widge = widgets.FloatText(value=mass, disabled=False)
    
    display(mass_text,mass_widge,hline)

    ## CALCULATION UNITS
    unit_text = widgets.HTML(
        value = "<b>Units -</b> Select calculation units",
    )

    unit_widge = widgets.RadioButtons(
        options=['SI', 'Cgs'],
        value=units,
        disabled=False
    )

    display(unit_text,unit_widge,hline)

    ## DRIFT CORRECTION
    drift_text = widgets.HTML(
        value = "<b>Drift correction -</b> Check the box below to perform measurement drift correction",
    )

    drift_widge = widgets.Checkbox(
        value=False,
        disabled=False
    )

    display(drift_text,drift_widge,hline)

    ## HIGH-FIELD SLOPE CORRECTION
    slope_text = widgets.HTML(
        value = "<b>High-field slope correction -</b> Check the box below to perform high-field slope correction",
    )

    slope_widge = widgets.Checkbox(
        value=False,
        disabled=False
    )

    display(slope_text,slope_widge,hline)

    ## FIRST-POINT ARTIFACT
    fpa_text = widgets.HTML(
        value = "<b>First point artifact -</b> Check the box below to remove first point artifact",
    )

    fpa_widge = widgets.Checkbox(
        value=False,
        disabled=False
    )

    display(fpa_text,fpa_widge,hline)


    ## FIRST-POINT ARTIFACT
    lpa_text = widgets.HTML(
        value = "<b>Last point artifact -</b> Check the box below to remove last point artifact",
    )

    lpa_widge = widgets.Checkbox(
        value=False,
        disabled=False
    )

    display(lpa_text,lpa_widge,hline)


    ## REMOVE OUTLIERS
    outlier_text = widgets.HTML(
        value = "<b>Remove outliers -</b> Check the box below to remove outliers",
    )

    outlier_widge = widgets.Checkbox(
        value=False,
        disabled=False
    )

    display(outlier_text,outlier_widge,hline)

    ## LOWER BRANCH SUBTRACT
    lbs_text = widgets.HTML(
        value = "<b>Subtract lower branch -</b> Check the box below to subtract the lower hysteresis branch",
    )

    lbs_widge = widgets.Checkbox(
        value=False,
        disabled=False
    )

    display(lbs_text,lbs_widge,hline)

    ## PLOTS 
    plot_text = widgets.HTML(
        value = "<b>Plots -</b> Select preprocessing plotting option",
    )

    plot_widge = widgets.Select(
        options=['No Plots', 'Plot results', 'Plot results and download'],
        value='Plot results',
        rows=3,
        disabled=False
    )

    display(plot_text,plot_widge,hline)

    ## PACK RESULTS INTO DICTIONARY
    pp0 = {
        "name": sample_widge,
        "mass": mass_widge,
        "unit": unit_widge,
        "drift": drift_widge,
        "slope": slope_widge,
        "fpa": fpa_widge,
        "lpa": lpa_widge,
        "outlier": outlier_widge,
        "lbs": lbs_widge,
        "plot": plot_widge,
    }
    
    return pp0

def data_preprocessing(fn,pp0):

    #copy current state of widget options
    pp = {
        "name": pp0["name"].value,
        "mass": pp0["mass"].value,
        "unit": pp0["unit"].value,
        "drift": pp0["drift"].value,
        "slope": pp0["slope"].value,
        "fpa": pp0["fpa"].value,
        "lpa": pp0["lpa"].value,
        "outlier": pp0["outlier"].value,
        "lbs": pp0["lbs"].value,
        "plot": pp0["plot"].value,
    }
  
    #parse measurements
    H, Hr, M, Fk, Fj, Ft, dH = parse_measurements(fn)
    Hcal, Mcal, tcal = parse_calibration(fn)
  
    # make a data dictionary for passing large numbers of arguments
    # should unpack in functions for consistency
    data = {
        "H":H,
        "Hr": Hr,
        "M": M,
        "dH": dH,
        "Fk": Fk,
        "Fj": Fj,
        "Ft": Ft,
        "Hcal": Hcal,
        "Mcal": Mcal,
        "tcal": tcal  
    }
  
    if pp["drift"] == True:
        data = drift_correction(data)   
  
    data = convert_units(pp,data,fn)
  
    if pp["mass"] > 0.0:
        data = mass_normalize(pp,data)
  
    if pp["slope"] == True:
        data = slope_correction(data)
  
    if pp["fpa"] == True:
        data = remove_fpa(data)
    
    if pp["lpa"] == True:
        data = remove_lpa(data)
    
    if pp["outlier"] == True:
        data = remove_outliers(data)
  
    if pp["lbs"] == True:
        data = lowerbranch_subtract(data)
  
    if pp["plot"] != "No Plots":
        plot_hysteresis(pp,data)
        if pp["lbs"] == True:
            plot_delta_hysteresis(pp,data)
    
    return pp, data

### NEW CODE
def sample_details(fn):

#  sample = "."
#  if len(fn.split(sample))>1:
#    sample = sample.join(fn.split(sample)[:-1])
#  else:
#    sample = fn.split(sample)
  
#  if type(sample) is list:
#    sample=sample[0]

  sample = fn.split('/')[-1]
  sample = sample.split('.')
  if type(sample) is list:
    sample=sample[0]

  units=parse_units(fn)
  mass=parse_mass(fn)
  
  return sample, units, mass

#def load_file():
  
#  uploaded = files.upload()
#  for fn in uploaded.keys():
#    print('User uploaded FORC file "{name}"'.format(name=fn))
  
#  sample, units, mass = sample_details(fn)
  
#  return sample, units, mass, fn

def check_pp(fn, pp):
  
  sample0, units0, mass0 = sample_details(fn)
  
  print('Preprocessing setting check')
  print('---------------------------')
  print(' ')
  
  status = 1
  # test: sample name
  if type(pp["sample name"]) is not str:
    status = -1
    cprint('Error: Sample name is not a character string','red')
  else:
    cprint('Sample name: '+pp["sample name"],'green')
  
  # test: sample mass
  if (pp["sample mass (g)"] == 'N/A'):
    cprint('Sample mass (g): '+ pp["sample mass (g)"],'green')
  elif (type(pp["sample mass (g)"]) is not float) or (pp["sample mass (g)"]<=0.0):
    status = -1
    cprint('Error: Sample mass is not a valid number','red')
  else:
    cprint('Sample mass (g): '+str(pp["sample mass (g)"]),'green')

  # test: units
  if (pp["units"] != 'SI') and (pp["units"] != 'Cgs'):
    status = -1
    cprint('Error: Units should be "SI" or "Cgs"','red')
  elif (pp["units"] == 'SI') and (units0 == 'Cgs'):
    status = 0
    cprint('Inconsistency: Units do not match those in the data file','blue')
  elif (pp["units"] == 'Cgs') and (units0 == 'SI'):
    status = 0
    cprint('Inconsistency: Units do not match those in the data file','blue')
  else:
    cprint('Units: '+str(pp["units"]),'green')

  # test: mass normalization
  if (pp["mass normalize"] != True) and (pp["mass normalize"] != False):
    status = -1
    cprint('Error: Mass normalization should be True or False','red')
  elif (pp["mass normalize"] is True) and (pp["sample mass (g)"] == 'N/A'):
    status = -1
    cprint('Error: Mass normalization requested, but no mass provided','red')
  elif (pp["mass normalize"] is True) and (pp["sample mass (g)"] != mass0) and (mass0 != 'N/A'):
    status = 0
    cprint('Inconsistency: Provided mass and data file mass are different','blue')
  else:
    cprint('Mass normalize: '+str(pp["mass normalize"]),'green')
  
  # test: drift correction
  if (pp["drift correction"] != True) and (pp["drift correction"] != False):
    status = -1
    cprint('Error: Drift correction should be True or False','red')
  else:
    cprint('Drift correction: '+str(pp["drift correction"]),'green')
  
  # test: high field slope correction
  if (pp["high field slope correction"] != True) and (pp["high field slope correction"] != False):
    status = -1
    cprint('Error: High field slope correction should be True or False','red')
  else:
    cprint('High field slope correction: '+str(pp["high field slope correction"]),'green')
  
  # test: first point artifact
  if (pp["first point artifact"] != True) and (pp["first point artifact"] != False):
    status = -1
    cprint('Error: First point artifact should be True or False','red')
  else:
    cprint('First point artifact: '+str(pp["first point artifact"]),'green')

  # test: replace outliers
  if (pp["replace outliers"] != True) and (pp["replace outliers"] != False):
    status = -1
    cprint('Error: Replace outliers should be True or False','red')
  else:
    cprint('Replace outliers: '+str(pp["replace outliers"]),'green')
    
  # test: subtract lower branch
  if (pp["subtract lower branch"] != True) and (pp["subtract lower branch"] != False):
    status = -1
    cprint('Error: Subtract lower branch should be True or False','red')
  else:
    cprint('Subtract lower branch: '+str(pp["subtract lower branch"]),'green')

   # test: plots
  if (pp["plots"] != True) and (pp["plots"] != False):
    status = -1
    cprint('Error: Plots option should be True or False','red')
  else:
    cprint('Plots: '+str(pp["plots"]),'green')
  
  # test: save plots
  if (pp["save plots"] != True) and (pp["save plots"] != False):
    status = -1
    cprint('Error: Save plots option should be True or False','red')
  else:
    cprint('Save plots: '+str(pp["save plots"]),'green')  
  
  cprint(' ')
  
  if status == -1:  
    cprint('--------------------------------------------------------------','red')
    cprint('There are errors in your settings, your analysis will not run!','red')
    cprint('A video tutorial on these settings is provided above.','red')
    cprint('--------------------------------------------------------------','red')
  
  if status == 0:  
    cprint('-----------------------------------------------------------------------','blue')
    cprint('There are inconsistencies in your settings, but your analysis will run!','blue')
    cprint('A video tutorial on these settings is provided above.','blue')
    cprint('-----------------------------------------------------------------------','blue')
  
  if status == 1:  
    cprint('-------------------------------------------------------','green')
    cprint('There are no errors or inconsistencies in your settings','green')
    cprint('Your analysis is ready to run.','green')
    cprint('-------------------------------------------------------','green')


### DATA PREPROCESSING
def preprocessing(pp,fn):
  
  #parse measurements
  H, Hr, M, Fk, Fj, Ft, dH = parse_measurements(fn)
  Hcal, Mcal, tcal = parse_calibration(fn)
  
  # make a data dictionary for passing large numbers of arguments
  # should unpack in functions for consistency
  data = {
    "H":H,
    "Hr": Hr,
    "M": M,
    "dH": dH,
    "Fk": Fk,
    "Fj": Fj,
    "Ft": Ft,
    "Hcal": Hcal,
    "Mcal": Mcal,
    "tcal": tcal  
  }
  
  if pp["drift correction"] == True:
    data = drift_correction(data)   
  
  data = convert_units(pp,data,fn)
  
  if pp["mass normalize"] == True:
    data = mass_normalize(pp,data)
  
  if pp["high field slope correction"] == True:
    data = slope_correction(data)
  
  if pp["first point artifact"] == True:
    data = remove_fpa(data)
    
  if pp["last point artifact"] == True:
    data = remove_lpa(data)
    
  if pp["replace outliers"] == True:
    data = remove_outliers(data)
  
  if pp["subtract lower branch"] == True:
    data = lowerbranch_subtract(data)
  
  if pp["plots"] == True:
    plot_hysteresis(pp,data)
    if pp["subtract lower branch"] == True:
      plot_delta_hysteresis(pp,data)
    
  return data


# drift correction
def drift_correction(data):
  
  #unpack
  M = data["M"]
  Mcal = data["Mcal"]    
  Ft = data["Ft"]
  tcal = data["tcal"]
  
  #perform drift correction
  M=M*Mcal[0]/np.interp(Ft,tcal,Mcal,left=np.nan) #drift correction
  
  #repack
  data["M"] = M
  
  return data


def convert_units(pp,data,fn):
  
  _, unit, _ = sample_details(fn)

  if (pp["unit"] == 'SI') and (unit == 'Cgs'): #convert to CGS
    H = data["H"]
    M = data["M"]
    
    H = H/1E4 #convert T into Oe
    M = M/1E3
      
    data["H"] = H
    data["M"] = M
    
  elif (pp["unit"] == 'Cgs') and (unit == 'SI'): #convert to CGS
    H = data["H"]
    M = data["M"]
    
    H = H*1E4 #convert Oe into T
    M = M*1E3
      
    data["H"] = H
    data["M"] = M
      
  return data

def mass_normalize(pp,data):
  
  M = data["M"]
    
  if (pp["unit"] == 'SI'): 
    M = M / (pp["mass"]/1000.) #convert to AM^2/kg
      
  if (pp["unit"] == 'Cgs'): 
    M = M / pp["mass"] #convert to emu/g
      
  data["M"] = M
      
  return data


# slope correction
def slope_correction(data):
  
  #unpack
  H = data["H"]
  M = data["M"]
  
  # high field slope correction
  Hidx = H > 0.8 * np.max(H)
  p = np.polyfit(H[Hidx],M[Hidx],1)
  M = M - H*p[0]
  
  #repack
  data["M"]=M
  
  return data

# remove FPA
def remove_fpa(data):
    
    #unpack
    Fj = data["Fj"]
    H = data["H"]    
    Hr = data["Hr"]
    M = data["M"]
    Fk = data["Fk"]
    Fj = data["Fj"]
    Ft = data["Ft"]
    
    #remove first point artifact
    idx=((Fj==1.0))
    H=H[~idx]
    Hr=Hr[~idx]
    M=M[~idx]
    Fk=Fk[~idx]
    Fj=Fj[~idx]
    Ft=Ft[~idx]
    Fk=Fk-np.min(Fk)+1. #reset FORC number if required
    Fj=Fj-1.
    
    #repack
    data["Fj"] = Fj
    data["H"] = H   
    data["Hr"] = Hr
    data["M"] = M
    data["Fk"] = Fk
    data["Fj"] = Fj
    data["Ft"] = Ft        
    
    return data
  
# remove lPA
def remove_lpa(data):
    
    #unpack
    Fj = data["Fj"]
    H = data["H"]    
    Hr = data["Hr"]
    M = data["M"]
    Fk = data["Fk"]
    Fj = data["Fj"]
    Ft = data["Ft"]
    
    #remove last point artifact
    Nforc = int(np.max(Fk))
    W = np.ones(Fk.size)
    
    for i in range(Nforc):      
      Fj_max=np.sum((Fk==i))
      idx = ((Fk==i) & (Fj==Fj_max))
      W[idx]=0.0
    
    idx = (W > 0.5)
    H=H[idx]
    Hr=Hr[idx]
    M=M[idx]
    Fk=Fk[idx]
    Fj=Fj[idx]
    Ft=Ft[idx]
    Fk=Fk-np.min(Fk)+1. #reset FORC number if required
    
    #repack
    data["Fj"] = Fj
    data["H"] = H   
    data["Hr"] = Hr
    data["M"] = M
    data["Fk"] = Fk
    data["Fj"] = Fj
    data["Ft"] = Ft        
    
    return data
  
def remove_outliers(data):
    
    """Function to replace "bad" measurements to zero.
    
    Inputs:
    H: Measurement applied field [float, SI units]
    Hr: Reversal field [float, SI units]
    M: Measured magnetization [float, SI units]
    Fk: Index of measured FORC (int)
    Fj: Index of given measurement within a given FORC (int)
    
    Outputs:
    Fmask: mask, accepted points = 1, rejected points = 0
    R: residuals from fitting process
    Rcrit: critical residual threshold 
    
    """
    #unpack variables
    H = data["H"]    
    Hr = data["Hr"]
    M = data["M"]
    Fk = data["Fk"]
    Fj = data["Fj"]
    
    SF=2 #half width of the smooth (full width = 2SF+1)
    Mst=np.zeros(M.size)*np.nan #initialize output of smoothed magnetizations
    for i in range(M.size): #loop through each measurement
        idx=((Fk==Fk[i]) & (Fj<=Fj[i]+SF) & (Fj>=Fj[i]-SF)) #finding smoothing window in terms of H
        Npts=np.sum(idx) #check enough points are available (may not be the case as edges)
        if Npts>3:
            #create centered quadratic design matrix WRT H
            A = np.concatenate((np.ones(Npts)[:,np.newaxis],\
                                (H[idx]-H[i])[:,np.newaxis],\
                                ((H[idx]-H[i])**2)[:,np.newaxis]),axis=1)
            Mst[i] = np.linalg.lstsq(A,M[idx],rcond=None)[0][0] #regression estimate of M
        else:
            Mst[i] = M[i] #not enough points, so used M

    Mstst=np.zeros(M.size)*np.nan
    for i in range(M.size):
        idx=((Fk<=Fk[i]+SF) & (Fk>=Fk[i]-SF)  & (Fk[i]-Fk+(Fj-Fj[i])==0))
        Npts=np.sum(idx)
        if Npts>3:
            #create centered quadratic design matrix WRT Hr
            A = np.concatenate((np.ones(Npts)[:,np.newaxis],\
                                (Hr[idx]-Hr[i])[:,np.newaxis],\
                                ((Hr[idx]-Hr[i])**2)[:,np.newaxis]),axis=1)
            Mstst[i] = np.linalg.lstsq(A,Mst[idx],rcond=None)[0][0] #regression estimate of Mst
        else: 
            Mstst[i] = Mst[i] #not enough points, so used Mst
            
    
    R = Mstst-Mst #estimated residuals
    Rcrit = np.std(R)*2.5 #set cut-off at 2.5 sigma
    Fmask=np.ones(M.size) #initialize mask
    Fmask[np.abs(R)>Rcrit]=0.0
    
    idx = (np.abs(R)<Rcrit) #points flagged as outliers
    
    #remove points deemed to be outliers
    H = H[idx]
    Hr = Hr[idx]
    M = M[idx]
    Fk = Fk[idx]
    Fj = Fj[idx]
      
    #reset indicies as required
    Fk = Fk - np.min(Fk)+1
  
    Nforc = int(np.max(Fk))
    for i in range(Nforc):
      idx = (Fk == i)
      idx0 = np.argsort(Fj[idx])
      for i in range(idx.size):
        Fj[idx[idx0[i]]] = i+1
    
    #repack variables
    H = data["H"]    
    Hr = data["Hr"]
    M = data["M"]
    Fk = data["Fk"]
    Fj = data["Fj"]
    
    
    
    return data
  
def lowerbranch_subtract(data):
    """Function to subtract lower hysteresis branch from FORC magnetizations
    
    Inputs:
    H: Measurement applied field [float, SI units]
    Hr: Reversal field [float, SI units]
    M: Measured magnetization [float, SI units]
    Fk: Index of measured FORC (int)
    Fj: Index of given measurement within a given FORC (int)
    
    Outputs:
    M: lower branch subtracted magnetization [float, SI units]
   
    
    """
    
    #unpack
    H = data["H"]    
    Hr = data["Hr"]
    M = data["M"]
    Fk = data["Fk"]
    Fj = data["Fj"]
    
    idx=(Fj==1) #define the upper branch based on the 1st measurement point in each FORC
    Hupper=-H[idx] #upper branch applied field (minus is to convert to lower branch)
    Mupper=-M[idx] #upper branch magnetization (minus is to convert to lower branch)

    idx=(Fk==np.max(Fk)) #use the last FORC to represent the lower branch
    Hlower=H[idx] #lower branch applied field
    Mlower=M[idx] #lower branch magnetization

    #adjust offset between upper and lower branch if required
    Mtest=Mupper-np.interp(Hlower[-1],Hupper,Mupper,left=np.nan,right=np.nan)+Mlower[-1]
    idx=Hupper>Hlower[-1]
    Hupper=Hupper[idx]
    Mupper=Mtest[idx]

    Hlower=np.concatenate((Hlower,Hupper)) #combine fields
    Mlower=np.concatenate((Mlower,Mupper)) #correct upper offset and combine magnetizations
    
    Mcorr=M-np.interp(H,Hlower,Mlower,left=np.nan,right=np.nan) #subtracted lower branch from FORCs via interpolation

    Fk=Fk[~np.isnan(Mcorr)] #remove any nan
    Fj=Fj[~np.isnan(Mcorr)] #remove any nan
    H=H[~np.isnan(Mcorr)] #remove any nan
    Hr=Hr[~np.isnan(Mcorr)] #remove any nan
    M=M[~np.isnan(Mcorr)] #remove any nan
    Mcorr = Mcorr[~np.isnan(Mcorr)] #remove any nan
    
    #repack
    data["H"] = H    
    data["Hr"] = Hr
    data["M"] = M
    data["Fk"] = Fk
    data["Fj"] = Fj
    data["DM"] = Mcorr
    
    
    return data
  
def plot_hysteresis(pp,data):

  #unpack 
  sample = pp["name"]
  M = data["M"]
  H = data["H"]
  Fk = data["Fk"]

  #mpl.style.use('seaborn-whitegrid')
  hfont = {'fontname':'STIXGeneral'}

  fig, ax = plt.subplots(figsize=(8,8))

  for i in range(5,int(np.max(Fk)),7):
    
    if pp["unit"] == "Cgs":
      ax.plot(H[Fk==i],M[Fk==i],'-k')
    else:
      ax.plot(H[Fk==i]*1000,M[Fk==i],'-k')

  ax.grid(False)
  ax.minorticks_on()
  ax.tick_params(axis='both',which='major',direction='out',length=5,width=1,labelsize=12,color='k')
  ax.tick_params(axis='both',which='minor',direction='out',length=5,width=1,color='k')

  ax.spines['left'].set_position('zero')
  ax.spines['left'].set_color('k')

  # turn off the right spine/ticks
  ax.spines['right'].set_color('none')
  ax.yaxis.tick_left()
  ylim=np.max(np.abs(ax.get_ylim()))
  ax.set_ylim([-ylim,ylim])
  
  #ax.set_ylim([-1,1])
  yticks0 = ax.get_yticks()
  yticks = yticks0[yticks0 != 0]
  ax.set_yticks(yticks)
  
  # set the y-spine
  ax.spines['bottom'].set_position('zero')
  ax.spines['bottom'].set_color('k')

  # turn off the top spine/ticks
  ax.spines['top'].set_color('none')
  ax.xaxis.tick_bottom()
  xmax = np.max(np.abs(ax.get_xlim()))
  ax.set_xlim([-xmax,xmax])
  #Xticks = ax.get_xticks()
  #Xidx = np.argwhere(np.abs(Xticks)>0.01)
  #ax.set_xticks(Xticks[Xidx])

  #label x-axis according to unit system
  if pp["unit"]=="Cgs":
    ax.set_xlabel('H [Oe]',horizontalalignment='right', position=(1,25), fontsize=12)
  else:
    ax.set_xlabel('B [mT]',horizontalalignment='right', position=(1,25), fontsize=12)

  #label y-axis according to unit system
  if ((pp["unit"]=="SI") and (pp["mass"] > 0.0)):
    ax.set_ylabel('M [Am2/kg]',verticalalignment='top',position=(25,0.9), fontsize=12,**hfont)
  elif ((pp["unit"]=="SI") and (pp["mass"] <= 0.0)): 
    ax.set_ylabel('M [Am2]',verticalalignment='top',position=(25,0.9), fontsize=12,**hfont)
  elif ((pp["unit"]=="Cgs") and (pp["mass"] > 0.0)): 
    ax.set_ylabel('M [emu/g]',verticalalignment='top',position=(25,0.9), fontsize=12,**hfont)
  elif ((pp["unit"]=="Cgs") and (pp["mass"] <= 0.0)): 
    ax.set_ylabel('M [emu]',verticalalignment='top',position=(25,0.9), fontsize=12,**hfont)

  #if pp["plot"] == 'Plot results and download':
  #    plt.savefig(sample+'_hys.pdf',bbox_inches="tight")
  #    files.download(sample+'_hys.pdf')

  plt.show()
  
  
def plot_delta_hysteresis(pp,data):

  #unpack 
  sample = pp["name"]
  M = data["DM"]
  H = data["H"]
  Fk = data["Fk"]

  #mpl.style.use('seaborn-whitegrid')
  hfont = {'fontname':'STIXGeneral'}

  fig, ax = plt.subplots(figsize=(8,8))

  for i in range(5,int(np.max(Fk)),7):
    
    if pp["unit"] == "Cgs":
      ax.plot(H[Fk==i],M[Fk==i],'-k')
    else:
      ax.plot(H[Fk==i]*1000,M[Fk==i],'-k')
      
  ax.grid(False)
  ax.minorticks_on()
  ax.tick_params(axis='both',which='major',direction='out',length=5,width=1,labelsize=12,color='k')
  ax.tick_params(axis='both',which='minor',direction='out',length=5,width=1,color='k')

  ax.spines['left'].set_position('zero')
  ax.spines['left'].set_color('k')

  # turn off the right spine/ticks
  ax.spines['right'].set_color('none')
  ax.yaxis.tick_left()
  #ax.set_ylabel('M / M$_0$',verticalalignment='top',position=(25,0.9), fontsize=12,**hfont)
  ylim=np.max(np.abs(ax.get_ylim()))
  ax.set_ylim([-ylim*0.1,ylim])
  yticks0 = ax.get_yticks()
  yticks = yticks0[yticks0 != 0]
  ax.set_yticks(yticks)
  
  # set the y-spine
  ax.spines['bottom'].set_position('zero')
  ax.spines['bottom'].set_color('k')

  # turn off the top spine/ticks
  ax.spines['top'].set_color('none')
  ax.xaxis.tick_bottom()
  #ax.set_xlabel('B [mT]',horizontalalignment='right', position=(1,25), fontsize=12)
  xmax = np.max(np.abs(ax.get_xlim()))
  ax.set_xlim([-xmax,xmax])
  Xticks = ax.get_xticks()
  Xidx = np.argwhere(np.abs(Xticks)>0.01)
  ax.set_xticks(Xticks[Xidx])

   #label x-axis according to unit system
  if pp["unit"]=="Cgs":
    ax.set_xlabel('H [Oe]',horizontalalignment='right', position=(1,25), fontsize=12)
  else:
    ax.set_xlabel('B [mT]',horizontalalignment='right', position=(1,25), fontsize=12)

  #label y-axis according to unit system
  if ((pp["unit"]=="SI") and (pp["mass"] > 0.0)):
    ax.set_ylabel('M - Mhys [Am2/kg]',verticalalignment='top',position=(25,0.9), fontsize=12,**hfont)
  elif ((pp["unit"]=="SI") and (pp["mass"] <= 0.0)): 
    ax.set_ylabel('M - Mhys [Am2]',verticalalignment='top',position=(25,0.9), fontsize=12,**hfont)
  elif ((pp["unit"]=="Cgs") and (pp["mass"] > 0.0)): 
    ax.set_ylabel('M - Mhys [emu/g]',verticalalignment='top',position=(25,0.9), fontsize=12,**hfont)
  elif ((pp["unit"]=="Cgs") and (pp["mass"] <= 0.0)): 
    ax.set_ylabel('M - Mhys [emu]',verticalalignment='top',position=(25,0.9), fontsize=12,**hfont)
  
  #if pp["plots"] == 'Plot results and download':
  #  plt.savefig(sample+'_delta.pdf',bbox_inches="tight")
  #  files.download(sample+'_delta.pdf')

  plt.show()

###

# define function which will look for lines in the header that start with certain strings
def find_data_lines(fp):
    """Helper function to identify measurement lines in a FORC data file.
    
    Given the various FORC file formats, measurements lines are considered to be those which:
    Start with a '+' or,
    Start with a '-' or,
    Are blank (i.e. lines between FORCs and calibration points) or,
    Contain a ','

    Inputs:
    fp: file identifier

    Outputs:
    line: string corresponding to data line that meets the above conditions
    """
    return [line for line in fp if ((line.startswith('+')) or (line.startswith('-')) or (line.strip()=='') or line.find(',')>-1.)]

#function to parse calibration points and provide time stamps
def lines_that_start_with(string, fp):
    """Helper function to lines in a FORC data file that start with a given string
    
    Inputs:
    string: string to compare lines to 
    fp: file identifier

    Outputs:
    line: string corresponding to data line that meets the above conditions
    """
    return [line for line in fp if line.startswith(string)]

def parse_header(file,string):
    """Function to extract instrument settings from FORC data file header
    
    Inputs:
    file: name of data file (string)    
    string: instrument setting to be extracted (string)

    Outputs:
    output: value of instrument setting [-1 if setting doesn't exist] (float)
    """
    output=-1 #default output (-1 corresponds to no result, i.e. setting doesn't exist)
    with cd.open(file,"r",encoding='latin9') as fp: #open the data file (latin9 encoding seems to work, UTF and ASCII don't)
        for line in lines_that_start_with(string, fp): #find the line starting with the setting name
            idx = line.find('=') #Some file formats may contain an '='
            if idx>-1.: #if '=' found
                output=float(line[idx+1:]) #value taken as everything to right of '='
            else: # '=' not found
                idx = len(string) #length of the setting string 
                output=float(line[idx+1:])  #value taken as everything to right of the setting name 

    return output

def parse_units(file):
    """Function to extract instrument unit settings ('') from FORC data file header
    
    Inputs:
    file: name of data file (string)    

    Outputs:
    CGS [Cgs setting] or SI [Hybrid SI] (string)
    """
    string = 'Units of measure' #header definition of units
    with cd.open(file,"r",encoding='latin9') as fp: #open the data file (latin9 encoding seems to work, UTF and ASCII don't)
        for line in lines_that_start_with(string, fp): #find the line starting with the setting name
            idxSI = line.find('Hybrid SI') #will return location if string is found, otherwise returns -1
            idxCGS = line.find('Cgs') #will return location if string is found, otherwise returns -1
    
    if idxSI>idxCGS: #determine which unit string was found in the headerline and output
        return 'SI'
    else:
        return 'CGS'

def parse_mass(file):
    """Function to extract sample from FORC data file header
    
    Inputs:
    file: name of data file (string)    

    Outputs:
    Mass in g or N/A
    """
    output = 'N/A'
    string = 'Mass' #header definition of units
    with cd.open(file,"r",encoding='latin9') as fp: #open the data file (latin9 encoding seems to work, UTF and ASCII don't)
        for line in lines_that_start_with(string, fp): #find the line starting with the setting name
            idx = line.find('=') #Some file formats may contain an '='
            if idx>-1.: #if '=' found
                output=(line[idx+1:]) #value taken as everything to right of '='
            else: # '=' not found
                idx = len(string) #length of the setting string 
                output=(line[idx+1:])  #value taken as everything to right of the setting name
        
            if output.find('N/A') > -1:
                output = 'N/A'
            else:
                output = float(output)

    return output

def calibration_times(file, Npts):
    """Function to estimate the time at which calibration points were measured in a FORC sequence
    
    Follows the procedure given in:
    R. Egli (2013) VARIFORC: An optimized protocol for calculating non-regular first-order reversal curve (FORC) diagrams. Global and Planetary Change, 110, 302-320, doi:10.1016/j.gloplacha.2013.08.003.

    Inputs:
    file: name of data file (string)    
    Npts: number of calibration points (int)

    Outputs:
    tcal_k: Estimated times at which the calibration points were measured (float)
    """    
    Units=parse_units(file) #determine measurement system (CGS or SI)

    string='PauseRvrsl' #Pause at reversal field (new file format, -1 if not available)
    tr0=parse_header(file,string)
    
    string='PauseNtl' #Pause at reversal field (old file format, -1 if not available)
    tr1=parse_header(file,string)

    tr=np.max((tr0,tr1)) #select Pause value depending on file format
    
    string='Averaging time' #Measurement averaging time 
    tau=parse_header(file,string)

    string='PauseCal' #Pause at calibration point
    tcal=parse_header(file,string)

    string='PauseSat' #Pause at saturation field
    ts=parse_header(file,string)

    string='SlewRate' #Field slewrate
    alpha=parse_header(file,string)

    string='HSat' #Satuation field
    Hs=parse_header(file,string)

    string='Hb2' #upper Hb value for the FORC box
    Hb2=parse_header(file,string)

    string='Hb1' #lower Hb value for the FORC box
    Hb1=parse_header(file,string)

    string='Hc2' #upper Hc value for the FORC box (n.b. Hc1 is assumed to be 0)
    Hc2=parse_header(file,string)

    string='NForc' # Numer of measured FORCs (new file format, -1 if not available)
    N0=parse_header(file,string)

    string='NCrv'  # Numer of measured FORCs (old file format, -1 if not available)
    N1=parse_header(file,string)

    N=np.max((N0,N1)) #select Number of FORCs depending on file format

    if Units=='CGS':
        alpha=alpha/1E4 #convert from Oe to T
        Hs=Hs/1E4 #convert from Oe to T
        Hb2=Hb2/1E4 #convert from Oe to T
        Hb1=Hb1/1E4 #convert from Oe to T
    
    dH = (Hc2-Hb1+Hb2)/N #estimated field spacing
    
    #now following Elgi's estimate of the measurement time
    nc2 = Hc2/dH
    Dt1 = tr + tau + tcal + ts + 2.*(Hs-Hb2-dH)/alpha
    Dt2 = tr + tau + (Hc2-Hb2-dH)/alpha

    Npts=int(Npts)
    tcal_k=np.zeros(Npts)
    
    for k in range(1,Npts+1):
        if k<=1+nc2:
            tcal_k[k-1]=k*Dt1-Dt2+dH/alpha*k**2+(tau-dH/alpha)*(k-1)**2
        else:
            tcal_k[k-1]=k*Dt1-Dt2+dH/alpha*k**2+(tau-dH/alpha)*((k-1)*(1+nc2)-nc2)

    return tcal_k

def measurement_limts(fn,pp):
    """Function to find measurement limits and conver units if required

    Inputs:
    file: name of data file (string)    


    Outputs:
    Hc1: minimum Hc
    Hc2: maximum Hc
    Hb1: minimum Hb
    Hb2: maximum Hb
    """    
    Units0=parse_units(fn) #determine measurement system (CGS or SI)
    
    string='Hb2' #upper Hb value for the FORC box
    Hb2=parse_header(fn,string)

    string='Hb1' #lower Hb value for the FORC box
    Hb1=parse_header(fn,string)

    string='Hc2' #upper Hc value for the FORC box
    Hc2=parse_header(fn,string)

    string='Hc1' #lower Hc value for the FORC box
    Hc1=parse_header(fn,string)

    if (Units0=='Cgs') & (pp['unit']=='SI'): #convert CGS to SI
        Hc2=Hc2/1E4 #convert from Oe to T
        Hc1=Hc1/1E4 #convert from Oe to T
        Hb2=Hb2/1E4 #convert from Oe to T
        Hb1=Hb1/1E4 #convert from Oe to T
      
    if (Units0=='SI') & (pp['unit']=='Cgs'): #convert SI to Cgs
        Hc2=Hc2*1E4 #convert from Oe to T
        Hc1=Hc1*1E4 #convert from Oe to T
        Hb2=Hb2*1E4 #convert from Oe to T
        Hb1=Hb1*1E4 #convert from Oe to T    

    return Hc1, Hc2, Hb1, Hb2

def measurement_times(file,Fk,Fj):
    """Function to estimate the time at which magnetization points were measured in a FORC sequence
    
    Follows the procedure given in:
    R. Egli (2013) VARIFORC: An optimized protocol for calculating non-regular first-order reversal curve (FORC) diagrams. Global and Planetary Change, 110, 302-320, doi:10.1016/j.gloplacha.2013.08.003.

    Inputs:
    file: name of data file (string)    
    Fk: FORC indicies (int)
    Fj: Measurement indicies within given FORC

    Outputs:
    Ft: Estimated times at which the magnetization points were measured (float)
    """    
    Units=parse_units(file) #determine measurement system (CGS or SI)

    string='PauseRvrsl' #Pause at reversal field (new file format, -1 if not available)
    tr0=parse_header(file,string)
    
    string='PauseNtl' #Pause at reversal field (old file format, -1 if not available)
    tr1=parse_header(file,string)

    tr=np.max((tr0,tr1)) #select Pause value depending on file format
    
    string='Averaging time' #Measurement averaging time 
    tau=parse_header(file,string)

    string='PauseCal' #Pause at calibration point
    tcal=parse_header(file,string)

    string='PauseSat' #Pause at saturation field
    ts=parse_header(file,string)

    string='SlewRate' #Field slewrate
    alpha=parse_header(file,string)

    string='HSat' #Satuation field
    Hs=parse_header(file,string)

    string='Hb2' #upper Hb value for the FORC box
    Hb2=parse_header(file,string)

    string='Hb1' #lower Hb value for the FORC box
    Hb1=parse_header(file,string)

    string='Hc2' #upper Hc value for the FORC box (n.b. Hc1 is assumed to be 0)
    Hc2=parse_header(file,string)

    string='NForc' # Numer of measured FORCs (new file format, -1 if not available)
    N0=parse_header(file,string)

    string='NCrv'  # Numer of measured FORCs (old file format, -1 if not available)
    N1=parse_header(file,string)

    N=np.max((N0,N1)) #select Number of FORCs depending on file format

    if Units=='CGS':
        alpha=alpha/1E4 #convert from Oe to T
        Hs=Hs/1E4 #convert from Oe to T
        Hb2=Hb2/1E4 #convert from Oe to T
        Hb1=Hb1/1E4 #convert from Oe to T

    dH = (Hc2-Hb1+Hb2)/N #estimated field spacing
    
    #now following Elgi's estimate of the measurement time
    nc2 = Hc2/dH

    Dt1 = tr + tau + tcal + ts + 2.*(Hs-Hb2-dH)/alpha
    Dt3 = Hb2/alpha

    Npts=int(Fk.size)
    Ft=np.zeros(Npts)
    
    for i in range(Npts):
        if Fk[i]<=1+nc2:
            Ft[i]=Fk[i]*Dt1+Dt3+Fj[i]*tau+dH/alpha*(Fk[i]*(Fk[i]-1))+(tau-dH/alpha)*(Fk[i]-1)**2
        else:
            Ft[i]=Fk[i]*Dt1+Dt3+Fj[i]*tau+dH/alpha*(Fk[i]*(Fk[i]-1))+(tau-dH/alpha)*((Fk[i]-1)*(1+nc2)-nc2)

    return Ft

def parse_calibration(file):
    """Function to extract measured calibration points from a FORC sequence
    
    Inputs:
    file: name of data file (string)    

    Outputs:
    Hcal: sequence of calibration fields [float, SI units]
    Mcal: sequence of calibration magnetizations [float, SI units]
    tcal: Estimated times at which the calibration points were measured (float, seconds)
    """ 

    dum=-9999.99 #dum value to indicate break in measurement seqence between FORCs and calibration points
    N0=int(1E6) #assume that any file will have less than 1E6 measurements
    H0=np.zeros(N0)*np.nan #initialize NaN array to contain field values
    M0=np.zeros(N0)*np.nan #initialize NaN array to contain magnetization values
    H0[0]=dum #first field entry is dummy value
    M0[0]=dum #first magnetization entry is dummy value 

    count=0 #counter to place values in arrays
    with cd.open(file,"r",encoding='latin9') as fp: #open the data file (latin9 encoding seems to work, UTF and ASCII don't)
        for line in find_data_lines(fp): #does the current line contain measurement data
            count=count+1 #increase counter
            idx = line.find(',') #no comma indicates a blank linw
            if idx>-1: #line contains a comma
                H0[count]=float(line[0:idx]) #assign field value (1st column)
                line=line[idx+1:] #remove the leading part of the line (only characters after the first comma remain)
                idx = line.find(',') #find next comman
                if idx>-1: #comma found in line
                    M0[count]=float(line[0:idx]) #read values up to next comma (assumes 2nd column is magnetizations)
                else: #comma wasn't found   
                    M0[count]=float(line) # magnetization value is just the remainder of the line 
            else:
                H0[count]=dum #line is blank, so fill with dummy value
                M0[count]=dum #line is blank, so fill with dummy value

    idx_start=np.argmax(H0!=dum) #find the first line that contains data            
    M0=M0[idx_start-1:-1] #strip out leading dummy values from magnetizations, leaving 1 dummy at start of vector           
    M0=M0[~np.isnan(M0)] #remove any NaNs at the end of the array
    H0=H0[idx_start-1:-1] #strip out leading dummy values from magnetizations, leaving 1 dummy at start of vector
    H0=H0[~np.isnan(H0)] #remove any NaNs at the end of the array

    ## now need to pull out the calibration points, will be after alternate -9999.99 entries
    idxSAT = np.array(np.where(np.isin(H0, dum))) #location of dummy values
    idxSAT = np.ndarray.squeeze(idxSAT) #squeeze into 1D
    idxSAT = idxSAT[0::2]+1 #every second index+1 should be calibration points

    Hcal=H0[idxSAT[0:-1]] #calibration fields
    Mcal=M0[idxSAT[0:-1]] #calibration magnetizations
    tcal=calibration_times(file,Hcal.size) #estimate the time of each calibratio measurement

    Units=parse_units(file)
    if Units=='CGS': #ensure SI units
        Hcal=Hcal/1E4 #convert from Oe to T
        Mcal=Mcal/1E3 #convert from emu to Am^2

    return Hcal, Mcal, tcal

def parse_measurements(file):
    """Function to extract measurement points from a FORC sequence
    
    Inputs:
    file: name of data file (string)    

    Outputs:
    H: Measurement applied field [float, SI units]
    Hr: Reversal field [float, SI units]
    M: Measured magnetization [float, SI units]
    Fk: Index of measured FORC (int)
    Fj: Index of given measurement within a given FORC (int)
    Ft: Estimated times at which the points were measured (float, seconds)
    dH: Measurement field spacing [float SI units]
    """ 

    dum=-9999.99 #dum value to indicate break in measurement seqence between FORCs and calibration points
    N0=int(1E6) #assume that any file will have less than 1E6 measurements
    H0=np.zeros(N0)*np.nan #initialize NaN array to contain field values
    M0=np.zeros(N0)*np.nan #initialize NaN array to contain magnetization values
    H0[0]=dum #first field entry is dummy value
    M0[0]=dum #first magnetization entry is dummy value 

    count=0 #counter to place values in arrays
    with cd.open(file,"r",encoding='latin9') as fp: #open the data file (latin9 encoding seems to work, UTF and ASCII don't)
        for line in find_data_lines(fp): #does the current line contain measurement data
            count=count+1 #increase counter
            idx = line.find(',') #no comma indicates a blank linw
            if idx>-1: #line contains a comma
                H0[count]=float(line[0:idx]) #assign field value (1st column)
                line=line[idx+1:] #remove the leading part of the line (only characters after the first comma remain)
                idx = line.find(',') #find next comman
                if idx>-1: #comma found in line
                    M0[count]=float(line[0:idx]) #read values up to next comma (assumes 2nd column is magnetizations)
                else: #comma wasn't found   
                    M0[count]=float(line) # magnetization value is just the remainder of the line 
            else:
                H0[count]=dum #line is blank, so fill with dummy value
                M0[count]=dum #line is blank, so fill with dummy value

    idx_start=np.argmax(H0!=dum) #find the first line that contains data            
    M0=M0[idx_start-1:-1] #strip out leading dummy values from magnetizations, leaving 1 dummy at start of vector           
    M0=M0[~np.isnan(M0)] #remove any NaNs at the end of the array
    H0=H0[idx_start-1:-1] #strip out leading dummy values from magnetizations, leaving 1 dummy at start of vector
    H0=H0[~np.isnan(H0)] #remove any NaNs at the end of the array

    ## determine indicies of each FORC
    idxSAT = np.array(np.where(np.isin(H0, dum))) #find start address of each blank line
    idxSAT = np.ndarray.squeeze(idxSAT) #squeeze into 1D
    idxSTART = idxSAT[1::2]+1 #find start address of each FORC
    idxEND = idxSAT[2::2]-1 ##find end address of each FORC

    
    #Extract first FORC to initialize arrays 
    M=M0[idxSTART[0]:idxEND[0]+1] #Magnetization values
    H=H0[idxSTART[0]:idxEND[0]+1] #Field values
    Hr=np.ones(idxEND[0]+1-idxSTART[0])*H0[idxSTART[0]] #Reversal field values
    Fk=np.ones(idxEND[0]+1-idxSTART[0]) #index number of FORC
    Fj=np.arange(1,1+idxEND[0]+1-idxSTART[0])# measurement index within given FORC

    #Extract remaining FORCs one by one into into a long-vector
    for i in range(1,idxSTART.size):
        M=np.concatenate((M,M0[idxSTART[i]:idxEND[i]+1]))
        H=np.concatenate((H,H0[idxSTART[i]:idxEND[i]+1]))
        Hr=np.concatenate((Hr,np.ones(idxEND[i]+1-idxSTART[i])*H0[idxSTART[i]]))
        Fk=np.concatenate((Fk,np.ones(idxEND[i]+1-idxSTART[i])+i))
        Fj=np.concatenate((Fj,np.arange(1,1+idxEND[i]+1-idxSTART[i])))
    
    Units=parse_units(file) #Ensure use of SI units
    if Units=='CGS':
        H=H/1E4 #Convert Oe into T
        Hr=Hr/1E4 #Convert Oe into T
        M=M/1E3 #Convert emu to Am^2

    dH = np.mean(np.diff(H[Fk==np.max(Fk)])) #mean field spacing

    Ft=measurement_times(file,Fk,Fj) #estimated time of each measurement point

    return H, Hr, M, Fk, Fj, Ft, dH

def play_tutorial(tv0):
    
    test = tv0['index'].value
    idx = test.find(':')
    index = int(test[0:idx])

    #define list of tutorial videos
    tutorial = ['ilyS6K4ry3U'] #tutorial 1
    tutorial.append('6kCS_nJC72g') #tutorial 2
    tutorial.append('PSKQ3ZNQ_O8') #tutorial 3
        
    vid = YouTubeVideo(id = tutorial[index-1],autoplay=True)
    display(vid)

def tutorial_options(*arg):

    tut_widge = widgets.Dropdown(
        options=['1: Introduction', '2: Preprocessing options', '3: Plotting options'],
        value='1: Introduction',
        description='Select:',
        disabled=False,
    )

    display(tut_widge)

    tv0 = {
        "index": tut_widge,
    }
    
    return tv0