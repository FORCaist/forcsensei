# Example Package

This is a simple example of forcsensei package.