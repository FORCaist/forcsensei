from ipyfilechooser import FileChooser

def FORCfile():
    fc = FileChooser()
    display(fc)

    return fc
