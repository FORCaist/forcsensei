# Welcome to FORCsensei
Full details of the FORCsensei package can be found on our project webpage:
https://forcaist.github.io/FORCaist.github.io/