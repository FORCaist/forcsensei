# compile using: python3 setup.py sdist bdist_wheel
import forcsensei.load
import forcsensei.preprocess 
import forcsensei.regress
import forcsensei.results
import forcsensei.utils
import forcsensei.buttons